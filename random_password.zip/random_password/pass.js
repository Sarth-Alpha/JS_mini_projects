const uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lowercase = "abcdefghijklmnopqrstuvwxyz";
const numbers = "1234567890";
const symbols = "!@#$%^&*()_+/";



//selectors
const passbox = document.getElementById("pass-box");
const totalchar = document.getElementById("total-char");
const upperinput = document.getElementById("upper-case");
const lowerinput = document.getElementById("lower-case");
const numberinput = document.getElementById("numbers");
const symbolinput = document.getElementById("symbols");



const getRandomData = (dataSet) => {
    return dataSet[Math.floor(Math.random() * dataSet.length)]
}

const givepassword = (password = "") => {
    if(upperinput.checked)
    {
        password +=getRandomData(uppercase)
    }
    if(lowerinput.checked)
    {
        password +=getRandomData(lowercase)
    }
    if(numberinput.checked)
    {
        password +=getRandomData(numbers)
    }
    if(symbolinput.checked)
    {
        password +=getRandomData(symbols)
    }
    if(password.length <= totalchar.value)
    {
        return givepassword(password)
    }
    passbox.innerText = truncatestring(password,totalchar.value)
}
givepassword();



    document.getElementById("btn").addEventListener(
        "click",function()
        {
            givepassword();
         }
    )
    

        function truncatestring(str , num)
        {
            if(str.length > num)
            {
                let subStr = str.substring(0,num);
                return subStr;
            }else{
                return str;
            }
        }

